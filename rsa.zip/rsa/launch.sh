#!/bin/bash
cd "$(dirname "$0")"
java -Djava.library.path=./natives -jar rsa.jar

